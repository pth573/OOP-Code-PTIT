package org.example;

import java.io.*;
import java.util.*;
import java.util.concurrent.Callable;

public class Main
{
    public static void main(String[] args) throws IOException
    {
//        WordSet ws = new WordSet("VANBAN.in");
        WordSet ws = new WordSet("G:\\OneDrive - ptit.edu.vn\\Desktop\\JAVA ptit\\J07007\\src\\main\\java\\org\\example\\VANBAN.in");
        System.out.println(ws);
    }
}


